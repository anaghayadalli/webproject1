const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, 'public');
const files = fs.readdirSync(dir).filter(f => f.endsWith('.html'));

const newLogo = `<a href="index.html" class="logo">\n  <img src="images/logo.png" alt="TechNova Logo">\n</a>`;

for (let file of files) {
    const filePath = path.join(dir, file);
    let content = fs.readFileSync(filePath, 'utf8');

    // Replace the specific long style block
    content = content.replace(/<a href="index\.html" class="logo" style="display:\s*flex;\s*align-items:\s*center;\s*gap:\s*8px;">[\s\S]*?<\/a>/g, newLogo);

    // Replace the standard text style block
    content = content.replace(/<a href="index\.html" class="logo">Tech<span>Nova<\/span><\/a>/g, newLogo);

    // Replace dashboard style block
    content = content.replace(/<a href="index\.html" class="logo">\s*<img src="images\/logo\.png" alt="TechNova">\s*<span>TechNova<\/span>\s*<\/a>/g, newLogo);

    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`Updated ${file}`);
}
