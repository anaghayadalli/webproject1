const express = require("express");
const mysql = require("mysql2");
const session = require("express-session");
require("dotenv").config();

const app = express();


// ---------- middleware ----------
app.use(express.urlencoded({ extended: true }));
app.use(express.json());


app.use(session({
    secret: "technova",
    resave: false,
    saveUninitialized: true
}));


// ---------- MySQL ----------
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

db.connect(err => {
    if (err) {
        console.error("MySQL Connection Error:", err.message);
    } else {
        console.log("MySQL Connected");

        // Auto-initialize required tables for portability
        const createUsersTable = `
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                role VARCHAR(20) DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `;

        const createContactsTable = `
            CREATE TABLE IF NOT EXISTS contacts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL,
                phone VARCHAR(50),
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `;

        const createMessagesTable = `
            CREATE TABLE IF NOT EXISTS messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                text TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `;

        db.query(createUsersTable, (err) => {
            if (err) console.error("Error creating users table:", err.message);
        });
        db.query(createContactsTable, (err) => {
            if (err) console.error("Error creating contacts table:", err.message);
        });
        db.query(createMessagesTable, (err) => {
            if (err) console.error("Error creating messages table:", err.message);
        });
    }
});


// ---------- login check ----------
function checkLogin(req, res, next) {

    if (req.session.user) next();
    else res.redirect("/login.html");

}


// ---------- register ----------
app.post("/register", (req, res) => {
    const name = req.body.name?.trim();
    const email = req.body.email?.trim();
    const password = req.body.password;

    if (!name || !email || !password) {
        return res.status(400).json({ success: false, message: "Missing required fields." });
    }

    // Check if user already exists
    db.query("SELECT * FROM users WHERE email = ?", [email], (err, result) => {
        if (err) {
            console.error("Registration Check Error:", err.message);
            return res.status(500).json({ success: false, message: "Internal server error." });
        }

        if (result.length > 0) {
            return res.status(400).json({ success: false, message: "Email already registered." });
        }

        // Insert new user
        db.query(
            "INSERT INTO users(name, email, password, role) VALUES(?, ?, ?, 'user')",
            [name, email, password],
            (err) => {
                if (err) {
                    console.error("Register Insert Error:", err.message);
                    return res.status(500).json({ success: false, message: "Registration failed. Please try again." });
                }
                res.json({ success: true, redirect: "/login.html" });
            }
        );
    });
});


// ---------- login ----------
app.post("/login", (req, res) => {
    const email = req.body.email?.trim();
    const password = req.body.password;

    // Hardcoded Admin Check per user request
    if (email === "admin@technova.com" && password === "admin123") {
        req.session.user = { email, role: 'admin' };
        return req.session.save((err) => {
            if (err) console.error("Session Save Error:", err);
            return res.json({ success: true, redirect: "/dashboard.html" });
        });
    }

    // Normal User Check against MySQL
    db.query(
        "SELECT * FROM users WHERE email=? AND password=?",
        [email, password],
        (err, result) => {
            if (err) {
                console.error("Login Error:", err.message);
                return res.status(500).json({ success: false, message: "Server error during login." });
            }
            if (result && result.length > 0) {
                const user = result[0];
                req.session.user = { email: user.email, role: user.role };

                req.session.save((err) => {
                    if (err) console.error("Session Save Error:", err);
                    // Redirect admin to dashboard, others to home
                    const redirect = user.role === 'admin' ? "/dashboard.html" : "/index.html";
                    res.json({ success: true, redirect });
                });
            } else {
                res.status(401).json({ success: false, message: "Invalid email or password." });
            }
        }
    );
});

// ---------- Session Check API ----------
app.get("/api/me", (req, res) => {
    if (req.session && req.session.user) {
        res.json({ loggedIn: true, role: req.session.user.role });
    } else {
        res.json({ loggedIn: false });
    }
});

// ---------- Middleware to protect routes ----------
function requireAdmin(req, res, next) {
    if (req.session && req.session.user && req.session.user.role === 'admin') {
        next();
    } else {
        res.redirect("/login.html");
    }
}

// ---------- protected dashboard ----------
app.get("/dashboard.html", requireAdmin, (req, res) => {

    res.sendFile(__dirname + "/public/dashboard.html");

});


// ---------- logout ----------
app.get("/logout", (req, res) => {

    req.session.destroy(() => {
        res.redirect("/login.html");
    });

});


// ---------- contact ----------
app.post("/contact", (req, res) => {
    const { name, email, phone, message } = req.body;

    if (!name || !email || !message) {
        return res.status(400).json({ success: false, message: "Missing required fields" });
    }

    db.query(
        "INSERT INTO contacts(name, email, phone, message) VALUES(?, ?, ?, ?)",
        [name, email, phone || null, message],
        (err) => {
            if (err) {
                console.error("Contact save error:", err.message);
                return res.status(500).json({ success: false, message: "Failed to save message." });
            }
            res.json({ success: true, message: "Thank you! We will be in touch soon." });
        }
    );
});

// ---------- api/contact (alias) ----------
app.post("/api/contact", (req, res) => {
    res.redirect(307, "/contact");
});


// ---------- stats ----------
app.get("/api/stats", (req, res) => {

    db.query(
        "SELECT COUNT(*) AS users FROM users",
        (err, r1) => {

            if (err) {
                console.log(err);
                return res.send("error");
            }

            db.query(
                "SELECT COUNT(*) AS messages FROM messages",
                (err, r2) => {

                    if (err) {
                        console.log(err);
                        return res.send("error");
                    }

                    res.json({
                        users: r1[0].users,
                        messages: r2[0].messages
                    });

                }
            );

        }
    );

});


// ---------- AI (Ollama Integration with Fallback) ----------
const FALLBACK_RESPONSES = {
    "hello": "Hello! I'm TechNova's AI assistant. How can I help you today with your digital transformation or IT consulting needs?",
    "hi": "Hi there! Welcome to TechNova Solutions. Looking for IT strategy, cloud services, or AI solutions?",
    "services": "TechNova offers world-class Digital Strategy, Cloud & DevOps, AI & Analytics, and Cyber Security services. You can find more details on our Services page.",
    "cloud": "Our Cloud & DevOps expertise includes AWS, Azure, and GCP migrations, CI/CD pipelines, and infrastructure automation.",
    "ai": "We specialize in custom Machine Learning models, predictive analytics, and data platforms to turn your data into insights.",
    "contact": "You can reach us at hello@technova.in, call +91 80 4123 4567, or visit us in Vidyanagar, Hubli, Karnataka.",
    "help": "I can tell you about our services, provide contact details, or discuss how we can help your business grow through technology.",
    "about": "TechNova Solutions is a leading IT consulting firm since 2018, helping businesses navigate digital change with strategy and execution.",
    "strategy": "Our Digital Strategy services help align your IT investments with core business goals for sustainable growth.",
    "security": "We provide enterprise-grade Cyber Security solutions to protect your business assets and data from modern threats."
};

function getKeywordResponse(msg) {
    const lowerMsg = msg.toLowerCase();
    for (const key in FALLBACK_RESPONSES) {
        if (lowerMsg.includes(key)) {
            return FALLBACK_RESPONSES[key];
        }
    }
    return "I'm TechNova's AI assistant. While my advanced processing core is offline, I can still help you with questions about our services, cloud strategy, AI solutions, or contact information. How can I assist you today?";
}

app.get("/api/ai", async (req, res) => {
    let msg = req.query.msg;
    if (!msg) return res.send("No message provided");

    let botReply = "";
    let provider = "Ollama";

    try {
        const ollamaPayload = {
            model: "llama3",
            prompt: `You are a helpful IT consulting assistant for a company named TechNova Solutions. Keep your answers very short, concise, and professional (under 3 sentences). User says: "${msg}"`,
            stream: false
        };

        const ollamaResponse = await fetch("http://127.0.0.1:11434/api/generate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(ollamaPayload),
            signal: AbortSignal.timeout(5000) // 5s timeout
        });

        if (ollamaResponse.ok) {
            const data = await ollamaResponse.json();
            botReply = data.response;
        } else {
            throw new Error("Ollama not responding properly");
        }
    } catch (error) {
        console.log("Ollama unavailable, using fallback system.");
        botReply = getKeywordResponse(msg);
        provider = "Fallback";
    }

    // Store interaction in DB
    db.query(
        "INSERT INTO messages(text) VALUES(?)",
        [`User: ${msg} | Bot (${provider}): ${botReply}`],
        (err) => {
            if (err) console.log("Failed to log chat to DB:", err.message);
        }
    );

    res.send(botReply);
});

//static //
app.use(express.static("public"));

// ---------- port ----------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on ${PORT}`);
});
