/**
 * TechNova Solutions — Main JavaScript
 * Handles: navbar toggle, scroll effects, stats counter, AI chat widget
 */

document.addEventListener('DOMContentLoaded', () => {

  /* ======================================================
     1. HAMBURGER MENU TOGGLE
     ====================================================== */
  const toggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (toggle && navLinks) {
    toggle.addEventListener('click', () => {
      toggle.classList.toggle('open');
      navLinks.classList.toggle('active');
    });

    // Close menu when a nav link is clicked (mobile UX)
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        toggle.classList.remove('open');
        navLinks.classList.remove('active');
      });
    });
  }

  /* ======================================================
     2. SCROLL — ADD SHADOW TO NAVBAR
     ====================================================== */
  const header = document.querySelector('header');

  if (header) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 20) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }, { passive: true });
  }

  /* ======================================================
     3. ANIMATED NUMBER COUNTERS (Stats Section)
     ====================================================== */
  function animateCounter(el) {
    const target = el.dataset.target;        // e.g. "150", "98", "120", "45"
    const suffix = el.dataset.suffix || '';  // e.g. "+", "%", " Cr+"
    const prefix = el.dataset.prefix || '';  // e.g. "₹"
    const duration = 1800; // ms
    const steps = 60;
    const stepTime = duration / steps;

    // Parse numeric target
    const num = parseFloat(target);
    let current = 0;
    const increment = num / steps;

    const timer = setInterval(() => {
      current += increment;
      if (current >= num) {
        current = num;
        clearInterval(timer);
      }
      // Display integer or one decimal
      const display = Number.isInteger(num) ? Math.floor(current) : current.toFixed(1);
      el.textContent = prefix + display + suffix;
    }, stepTime);
  }

  // Use IntersectionObserver to trigger counter only when visible
  const statNumbers = document.querySelectorAll('.stat-number[data-target]');

  if (statNumbers.length > 0) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });

    statNumbers.forEach(el => observer.observe(el));
  }

  /* ======================================================
     3B. SCROLL REVEAL ANIMATIONS
     ====================================================== */
  const revealElements = document.querySelectorAll('.reveal');
  if (revealElements.length > 0) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    revealElements.forEach(el => revealObserver.observe(el));
  }

  /* ======================================================
     4. AI CHAT WIDGET
     ====================================================== */
  const chatToggleBtn = document.getElementById('chat-toggle-btn');
  const chatbox = document.getElementById('chatbox');
  const chatMessages = document.getElementById('chat-messages');
  const msgInput = document.getElementById('msg');
  const sendBtn = document.getElementById('send-btn');
  const chatCloseBtn = document.getElementById('chat-close');

  // Toggle open/close
  if (chatToggleBtn && chatbox) {
    chatToggleBtn.addEventListener('click', () => {
      const isOpen = chatbox.style.display === 'block';
      chatbox.style.display = isOpen ? 'none' : 'block';

      // Show welcome message on first open
      if (!isOpen && chatMessages && chatMessages.children.length === 0) {
        appendBotMessage('👋 Hi! I\'m TechNova\'s AI assistant. Ask me about our services, company, or how to get in touch!');
      }

      if (!isOpen && msgInput) {
        setTimeout(() => msgInput.focus(), 100);
      }
    });
  }

  // Close button inside chat
  if (chatCloseBtn && chatbox) {
    chatCloseBtn.addEventListener('click', () => {
      chatbox.style.display = 'none';
    });
  }

  // Send message on button click or Enter key
  if (sendBtn) {
    sendBtn.addEventListener('click', sendMessage);
  }

  if (msgInput) {
    msgInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });
  }

  function appendUserMessage(text) {
    if (!chatMessages) return;
    const bubble = document.createElement('div');
    bubble.classList.add('msg-bubble', 'user');
    bubble.innerHTML = `<span class="msg-sender">You</span>${escapeHtml(text)}`;
    chatMessages.appendChild(bubble);
    scrollToBottom();
  }

  function appendBotMessage(text) {
    if (!chatMessages) return;
    const bubble = document.createElement('div');
    bubble.classList.add('msg-bubble', 'bot');
    bubble.innerHTML = `<span class="msg-sender">TechNova AI</span>${text}`;
    chatMessages.appendChild(bubble);
    scrollToBottom();
  }

  function appendTypingIndicator() {
    if (!chatMessages) return null;
    const el = document.createElement('div');
    el.classList.add('msg-bubble', 'bot');
    el.id = 'typing-indicator';
    el.innerHTML = `<span class="msg-sender">TechNova AI</span><em style="opacity:0.6">Typing…</em>`;
    chatMessages.appendChild(el);
    scrollToBottom();
    return el;
  }

  function scrollToBottom() {
    if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }

  function sendMessage() {
    if (!msgInput || !msgInput.value.trim()) return;

    const userText = msgInput.value.trim();
    msgInput.value = '';

    appendUserMessage(userText);

    // Show typing state
    const typing = appendTypingIndicator();

    // Call GET /api/ai
    fetch('/api/ai?msg=' + encodeURIComponent(userText))
      .then(r => r.text())
      .then(response => {
        // Minimum delay to feel "natural"
        setTimeout(() => {
          if (typing) typing.remove();
          appendBotMessage(escapeHtml(response));
        }, 800);
      })
      .catch(() => {
        setTimeout(() => {
          if (typing) typing.remove();
          appendBotMessage('Sorry, I\'m having trouble connecting to my brain right now. Please try again later.');
        }, 800);
      });
  }

  /* ======================================================
     5. AUTHENTICATION & UI LOGIC
     ====================================================== */
  function updateAuthUI() {
    fetch('/api/me')
      .then(res => res.json())
      .then(data => {
        // Dashboard Links
        const dashboardLinks = document.querySelectorAll('a[href="dashboard.html"]');
        const loginLinks = document.querySelectorAll('a[href="login.html"]');
        const registerLinks = document.querySelectorAll('a[href="register.html"]');

        // Find consultation buttons (e.g. .btn-primary hrefs on home)
        // Usually target class .btn-primary that links to contact or explicitly have text "Get Started"/"Consultation"
        const ctaButtons = document.querySelectorAll('.hero-btns a.btn-primary, .cta-btn, a[href="contact.html"].btn');

        if (data.loggedIn) {
          // Admin Check
          if (data.role === 'admin') {
            dashboardLinks.forEach(el => el.style.display = 'block');
          } else {
            dashboardLinks.forEach(el => el.style.display = 'none');
          }

          // Swap Login/Register for Logout UI
          loginLinks.forEach(el => el.style.display = 'none');
          registerLinks.forEach(el => {
            el.setAttribute('href', '/logout');
            el.textContent = 'Logout';
          });

          // Leave CTA active
        } else {
          // Not logged in
          dashboardLinks.forEach(el => el.style.display = 'none');

          // Protect Consultation buttons
          ctaButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
              e.preventDefault();
              alert("Please login first to book a consultation.");
              window.location.href = 'login.html';
            });
          });
        }
      })
      .catch(err => console.error("Auth check failed:", err));
  }

  // Execute auth check
  updateAuthUI();

});
